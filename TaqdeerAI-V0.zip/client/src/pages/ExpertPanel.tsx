import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { Plus, Trash2, Upload, Loader2, X, Image as ImageIcon } from "lucide-react";
import { useState, useRef } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";

interface DamageItem {
  damageType: string;
  description: string;
  partCost: number;
  laborCost: number;
  quantity: number;
}

export default function ExpertPanel() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <ExpertPanelContent />
    </div>
  );
}

function ExpertPanelContent() {
  const { user, loading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  
  // All hooks must be called before any conditional returns
  const { data: stats } = trpc.rating.getRatingStatistics.useQuery();
  
  const [vehicleAge, setVehicleAge] = useState<number>();
  const [mileage, setMileage] = useState<number>();
  const [vehicleType, setVehicleType] = useState("");
  const [accidentType, setAccidentType] = useState("");
  const [damageSeverity, setDamageSeverity] = useState("");
  const [notes, setNotes] = useState("");
  const [damageItems, setDamageItems] = useState<DamageItem[]>([
    { damageType: "", description: "", partCost: 0, laborCost: 0, quantity: 1 }
  ]);
  const [images, setImages] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const createAssessment = trpc.expert.createAssessment.useMutation({
    onSuccess: () => {
      toast.success("تم حفظ التقييم بنجاح!");
      // Reset form
      setVehicleAge(undefined);
      setMileage(undefined);
      setVehicleType("");
      setAccidentType("");
      setDamageSeverity("");
      setNotes("");
      setDamageItems([{ damageType: "", description: "", partCost: 0, laborCost: 0, quantity: 1 }]);
      setImages([]);
      setImagePreviews([]);
    },
    onError: (error) => {
      toast.error("فشل حفظ التقييم: " + error.message);
    }
  });

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    
    files.forEach(file => {
      if (!file.type.startsWith('image/')) {
        toast.error(`${file.name} ليس ملف صورة`);
        return;
      }

      if (file.size > 10 * 1024 * 1024) {
        toast.error(`${file.name} حجمه كبير جداً (الحد الأقصى 10MB)`);
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreviews(prev => [...prev, e.target?.result as string]);
      };
      reader.readAsDataURL(file);
    });

    setImages(prev => [...prev, ...files]);
  };

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
    setImagePreviews(prev => prev.filter((_, i) => i !== index));
  };

  const addDamageItem = () => {
    setDamageItems([...damageItems, { damageType: "", description: "", partCost: 0, laborCost: 0, quantity: 1 }]);
  };

  const removeDamageItem = (index: number) => {
    setDamageItems(damageItems.filter((_, i) => i !== index));
  };

  const updateDamageItem = (index: number, field: keyof DamageItem, value: string | number) => {
    const updated = [...damageItems];
    updated[index] = { ...updated[index], [field]: value };
    setDamageItems(updated);
  };

  const calculateTotalCost = () => {
    return damageItems.reduce((sum, item) => 
      sum + (item.partCost + item.laborCost) * item.quantity, 0
    );
  };

  const calculateTotalLaborCost = () => {
    return damageItems.reduce((sum, item) => 
      sum + item.laborCost * item.quantity, 0
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (damageItems.length === 0 || !damageItems[0]?.damageType) {
      toast.error("يجب إضافة عنصر ضرر واحد على الأقل");
      return;
    }

    createAssessment.mutate({
      vehicleAge,
      mileage,
      vehicleType: vehicleType || undefined,
      accidentType: accidentType || undefined,
      damageSeverity: damageSeverity || undefined,
      notes: notes || undefined,
      totalCost: calculateTotalCost(),
      laborCost: calculateTotalLaborCost(),
      damageItems: damageItems.filter(item => item.damageType),
    });
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user || (user.role !== 'expert' && user.role !== 'admin')) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>غير مصرح</CardTitle>
            <CardDescription>هذه الصفحة متاحة للخبراء فقط</CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => navigate("/")}>العودة للصفحة الرئيسية</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 py-8">
      <div className="container max-w-4xl">
        {/* Statistics Card */}
        {stats && stats.totalRatings > 0 && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-2xl">إحصائيات دقة النموذج</CardTitle>
              <CardDescription>
                تقييمات المستخدمين لدقة التنبؤات
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg text-center">
                  <div className="text-sm text-blue-600 font-medium mb-1">إجمالي التقييمات</div>
                  <div className="text-3xl font-bold text-blue-900">{stats.totalRatings}</div>
                </div>
                <div className="bg-green-50 p-4 rounded-lg text-center">
                  <div className="text-sm text-green-600 font-medium mb-1">متوسط الدقة</div>
                  <div className="text-2xl font-bold text-green-900">
                    {stats.averageAccuracy.toFixed(1)}/5 ⭐
                  </div>
                </div>
                <div className="bg-purple-50 p-4 rounded-lg text-center">
                  <div className="text-sm text-purple-600 font-medium mb-1">فرق التكلفة</div>
                  <div className="text-2xl font-bold text-purple-900">
                    {Math.abs(stats.averageCostDifference).toFixed(0)} ر.س
                  </div>
                </div>
                <div className="bg-orange-50 p-4 rounded-lg text-center">
                  <div className="text-sm text-orange-600 font-medium mb-1">نسبة التوصية</div>
                  <div className="text-2xl font-bold text-orange-900">
                    {stats.recommendationRate.toFixed(0)}%
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle className="text-3xl">لوحة الخبراء - تعليم النموذج</CardTitle>
            <CardDescription>
              قم بإدخال تقييمات الأضرار لتحسين دقة نموذج التنبؤ
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Vehicle Information */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">معلومات المركبة</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="vehicleAge">عمر المركبة (سنوات)</Label>
                    <Input
                      id="vehicleAge"
                      type="number"
                      value={vehicleAge || ""}
                      onChange={(e) => setVehicleAge(e.target.value ? Number(e.target.value) : undefined)}
                      placeholder="5"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="mileage">المسافة المقطوعة (كم)</Label>
                    <Input
                      id="mileage"
                      type="number"
                      value={mileage || ""}
                      onChange={(e) => setMileage(e.target.value ? Number(e.target.value) : undefined)}
                      placeholder="80000"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="vehicleType">نوع المركبة</Label>
                    <Select value={vehicleType} onValueChange={setVehicleType}>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر نوع المركبة" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sedan">سيدان</SelectItem>
                        <SelectItem value="suv">دفع رباعي</SelectItem>
                        <SelectItem value="truck">شاحنة</SelectItem>
                        <SelectItem value="coupe">كوبيه</SelectItem>
                        <SelectItem value="hatchback">هاتشباك</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="accidentType">نوع الحادث</Label>
                    <Select value={accidentType} onValueChange={setAccidentType}>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر نوع الحادث" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="collision">تصادم</SelectItem>
                        <SelectItem value="scratch">خدش</SelectItem>
                        <SelectItem value="dent">انبعاج</SelectItem>
                        <SelectItem value="crack">شرخ</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="damageSeverity">مستوى الضرر</Label>
                    <Select value={damageSeverity} onValueChange={setDamageSeverity}>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر مستوى الضرر" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="minor">بسيط</SelectItem>
                        <SelectItem value="moderate">متوسط</SelectItem>
                        <SelectItem value="severe">شديد</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              {/* Damage Items */}
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold">تفاصيل الأضرار</h3>
                  <Button type="button" onClick={addDamageItem} variant="outline" size="sm">
                    <Plus className="w-4 h-4 ml-2" />
                    إضافة ضرر
                  </Button>
                </div>

                {damageItems.map((item, index) => (
                  <Card key={index} className="p-4">
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <Label>الضرر #{index + 1}</Label>
                        {damageItems.length > 1 && (
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => removeDamageItem(index)}
                          >
                            <Trash2 className="w-4 h-4 text-red-500" />
                          </Button>
                        )}
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div className="space-y-2">
                          <Label>نوع الضرر</Label>
                          <Input
                            value={item.damageType}
                            onChange={(e) => updateDamageItem(index, 'damageType', e.target.value)}
                            placeholder="مثال: خدش في الصدام الأمامي"
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>الكمية</Label>
                          <Input
                            type="number"
                            value={item.quantity}
                            onChange={(e) => updateDamageItem(index, 'quantity', Number(e.target.value))}
                            min="1"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>تكلفة القطع ($)</Label>
                          <Input
                            type="number"
                            step="0.01"
                            value={item.partCost}
                            onChange={(e) => updateDamageItem(index, 'partCost', Number(e.target.value))}
                            placeholder="0.00"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>تكلفة العمالة ($)</Label>
                          <Input
                            type="number"
                            step="0.01"
                            value={item.laborCost}
                            onChange={(e) => updateDamageItem(index, 'laborCost', Number(e.target.value))}
                            placeholder="0.00"
                          />
                        </div>
                        <div className="space-y-2 md:col-span-2">
                          <Label>الوصف</Label>
                          <Textarea
                            value={item.description}
                            onChange={(e) => updateDamageItem(index, 'description', e.target.value)}
                            placeholder="وصف تفصيلي للضرر..."
                            rows={2}
                          />
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>

              {/* Image Upload */}
              <div className="space-y-4">
                <Label>صور الأضرار (اختياري)</Label>
                <div
                  onClick={() => document.getElementById('expert-file-input')?.click()}
                  className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center cursor-pointer hover:border-primary transition-colors"
                >
                  <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                  <p className="text-sm font-medium mb-1">انقر لرفع الصور</p>
                  <p className="text-xs text-gray-500">PNG, JPG, WEBP (حد أقصى 10MB لكل صورة)</p>
                </div>
                <input
                  id="expert-file-input"
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleImageSelect}
                  className="hidden"
                />

                {/* Image Previews */}
                {imagePreviews.length > 0 && (
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {imagePreviews.map((preview, index) => (
                      <div key={index} className="relative group">
                        <img
                          src={preview}
                          alt={`Preview ${index + 1}`}
                          className="w-full h-24 object-cover rounded-lg"
                        />
                        <Button
                          type="button"
                          variant="destructive"
                          size="icon"
                          className="absolute top-1 right-1 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={() => removeImage(index)}
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Notes */}
              <div className="space-y-2">
                <Label htmlFor="notes">ملاحظات إضافية</Label>
                <Textarea
                  id="notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="أي ملاحظات أو تفاصيل إضافية..."
                  rows={3}
                />
              </div>

              {/* Summary */}
              <Card className="bg-blue-50">
                <CardContent className="pt-6">
                  <div className="space-y-2">
                    <div className="flex justify-between text-lg">
                      <span className="font-semibold">إجمالي تكلفة العمالة:</span>
                      <span className="font-bold text-blue-600">
                        ${calculateTotalLaborCost().toFixed(2)}
                      </span>
                    </div>
                    <div className="flex justify-between text-xl">
                      <span className="font-semibold">التكلفة الإجمالية:</span>
                      <span className="font-bold text-green-600">
                        ${calculateTotalCost().toFixed(2)}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Submit Button */}
              <Button 
                type="submit" 
                className="w-full" 
                size="lg"
                disabled={createAssessment.isPending}
              >
                {createAssessment.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                    جاري الحفظ...
                  </>
                ) : (
                  "حفظ التقييم"
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
