import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { Loader2, FileText, Calendar, DollarSign, Search, Filter, Eye, Star } from "lucide-react";
import { useState, useMemo } from "react";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";

export default function History() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <HistoryContent />
    </div>
  );
}

function HistoryContent() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  
  const [searchTerm, setSearchTerm] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  const { data: predictions, isLoading } = trpc.predict.getMyPredictions.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  // Filter and search predictions
  const filteredPredictions = useMemo(() => {
    if (!predictions) return [];

    return predictions.filter(prediction => {
      // Search filter
      const searchLower = searchTerm.toLowerCase();
      const matchesSearch = !searchTerm || 
        prediction.id.toString().includes(searchLower) ||
        prediction.vehicleType?.toLowerCase().includes(searchLower) ||
        prediction.accidentType?.toLowerCase().includes(searchLower) ||
        prediction.damageSeverity?.toLowerCase().includes(searchLower);

      // Date filter
      const predictionDate = new Date(prediction.createdAt);
      const matchesStartDate = !startDate || predictionDate >= new Date(startDate);
      const matchesEndDate = !endDate || predictionDate <= new Date(endDate + 'T23:59:59');

      // Status filter
      const matchesStatus = statusFilter === "all" || prediction.status === statusFilter;

      return matchesSearch && matchesStartDate && matchesEndDate && matchesStatus;
    }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [predictions, searchTerm, startDate, endDate, statusFilter]);

  const clearFilters = () => {
    setSearchTerm("");
    setStartDate("");
    setEndDate("");
    setStatusFilter("all");
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-green-600" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>تسجيل الدخول مطلوب</CardTitle>
            <CardDescription>يجب تسجيل الدخول لعرض سجل التقييمات</CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => window.location.href = getLoginUrl()} className="w-full bg-green-600 hover:bg-green-700">
              تسجيل الدخول
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-600 to-green-700 text-white py-12">
        <div className="container">
          <h1 className="text-4xl font-bold mb-2">سجل التقييمات</h1>
          <p className="text-green-100">جميع تقييماتك السابقة في مكان واحد</p>
        </div>
      </div>

      <div className="container py-8">
        {/* Filters */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Filter className="w-5 h-5 text-green-600" />
              <CardTitle>البحث والفلترة</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Search */}
              <div>
                <Label htmlFor="search">بحث</Label>
                <div className="relative">
                  <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="search"
                    placeholder="رقم التقييم، نوع المركبة..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pr-10"
                  />
                </div>
              </div>

              {/* Start Date */}
              <div>
                <Label htmlFor="startDate">من تاريخ</Label>
                <Input
                  id="startDate"
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                />
              </div>

              {/* End Date */}
              <div>
                <Label htmlFor="endDate">إلى تاريخ</Label>
                <Input
                  id="endDate"
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                />
              </div>

              {/* Status Filter */}
              <div>
                <Label htmlFor="status">الحالة</Label>
                <select
                  id="status"
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="w-full h-10 px-3 rounded-md border border-input bg-background"
                >
                  <option value="all">الكل</option>
                  <option value="completed">مكتمل</option>
                  <option value="pending">قيد المعالجة</option>
                  <option value="failed">فشل</option>
                </select>
              </div>
            </div>

            {/* Clear Filters */}
            {(searchTerm || startDate || endDate || statusFilter !== "all") && (
              <div className="mt-4">
                <Button onClick={clearFilters} variant="outline" size="sm">
                  مسح الفلاتر
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Results Count */}
        <div className="mb-4 text-sm text-gray-600">
          عرض {filteredPredictions.length} من {predictions?.length || 0} تقييم
        </div>

        {/* Predictions List */}
        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-green-600" />
          </div>
        ) : filteredPredictions.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <FileText className="w-16 h-16 mx-auto text-gray-300 mb-4" />
              <p className="text-gray-500 text-lg mb-2">
                {predictions && predictions.length > 0 ? "لا توجد نتائج مطابقة" : "لا توجد تقييمات بعد"}
              </p>
              <p className="text-gray-400 text-sm mb-4">
                {predictions && predictions.length > 0 ? "جرب تغيير معايير البحث" : "ابدأ بإنشاء تقييم جديد"}
              </p>
              <Button onClick={() => navigate("/predict")} className="bg-green-600 hover:bg-green-700">
                إنشاء تقييم جديد
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {filteredPredictions.map((prediction) => (
              <Card key={prediction.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    {/* Left Side - Info */}
                    <div className="flex-1">
                      <div className="flex items-start gap-4">
                        <div className="bg-green-100 p-3 rounded-lg">
                          <FileText className="w-6 h-6 text-green-600" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="text-lg font-semibold">تقييم #{prediction.id}</h3>
                            <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                              prediction.status === 'completed' ? 'bg-green-100 text-green-800' :
                              prediction.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-red-100 text-red-800'
                            }`}>
                              {prediction.status === 'completed' ? 'مكتمل' :
                               prediction.status === 'pending' ? 'قيد المعالجة' : 'فشل'}
                            </span>
                          </div>

                          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                            <div className="flex items-center gap-2 text-gray-600">
                              <Calendar className="w-4 h-4" />
                              <span>{new Date(prediction.createdAt).toLocaleDateString('ar-SA')}</span>
                            </div>
                            {prediction.vehicleType && (
                              <div className="text-gray-600">
                                <span className="font-medium">النوع:</span> {prediction.vehicleType}
                              </div>
                            )}
                            {prediction.accidentType && (
                              <div className="text-gray-600">
                                <span className="font-medium">الحادث:</span> {prediction.accidentType}
                              </div>
                            )}
                            {prediction.damageSeverity && (
                              <div>
                                <span className={`px-2 py-1 rounded text-xs ${
                                  prediction.damageSeverity === 'severe' ? 'bg-red-100 text-red-800' :
                                  prediction.damageSeverity === 'moderate' ? 'bg-yellow-100 text-yellow-800' :
                                  'bg-green-100 text-green-800'
                                }`}>
                                  {prediction.damageSeverity === 'severe' ? 'شديد' :
                                   prediction.damageSeverity === 'moderate' ? 'متوسط' : 'بسيط'}
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Right Side - Cost & Action */}
                    <div className="flex items-center gap-4 md:flex-col md:items-end">
                      <div className="text-right">
                        <div className="flex items-center gap-2 text-gray-500 text-sm mb-1">
                          <DollarSign className="w-4 h-4" />
                          <span>التكلفة المتوقعة</span>
                        </div>
                        <div className="text-2xl font-bold text-green-600">
                          {prediction.predictedTotalCost.toFixed(2)} ر.س
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button 
                          onClick={() => navigate(`/invoice/${prediction.id}`)}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <Eye className="w-4 h-4 ml-2" />
                          عرض الفاتورة
                        </Button>
                        <Button 
                          onClick={() => navigate(`/rate/${prediction.id}`)}
                          variant="outline"
                          className="border-green-600 text-green-600 hover:bg-green-50"
                        >
                          <Star className="w-4 h-4 ml-2" />
                          تقييم
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
