import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Camera, Brain, FileText, Users, ArrowRight, CheckCircle } from "lucide-react";
import { APP_LOGO, APP_TITLE, getLoginUrl } from "@/const";
import { useLocation } from "wouter";

export default function Home() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [, navigate] = useLocation();

  if (loading) {
   return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex-1 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 text-center">
      <Navbar />

      {/* Hero Section */}
      <section className="container py-20">
        <div className="max-w-4xl mx-auto text-center space-y-6">
          <h2 className="text-5xl font-bold bg-gradient-to-r from-green-700 to-green-500 bg-clip-text text-transparent">
            تقدير دقيق لأضرار المركبات باستخدام الذكاء الاصطناعي
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            نظام متقدم يجمع بين تقنيات Computer Vision وخبرة المتخصصين المحليين لتقديم تقديرات دقيقة ومفصلة لتكاليف إصلاح أضرار المركبات
          </p>
          <div className="flex gap-4 justify-center pt-4 flex-wrap">
            <Button 
              size="lg" 
              onClick={() => navigate("/predict")}
              className="bg-gradient-to-r from-green-700 to-green-600 hover:from-green-800 hover:to-green-700"
            >
              <Camera className="w-5 h-5 ml-2" />
              ابدأ التحليل الآن
              <ArrowRight className="w-5 h-5 mr-2" />
            </Button>
            {isAuthenticated && (
              <Button 
                size="lg" 
                variant="outline"
                onClick={() => navigate("/history")}
              >
                <FileText className="w-5 h-5 ml-2" />
                سجل التقييمات
              </Button>
            )}
            {isAuthenticated && (user?.role === 'expert' || user?.role === 'admin') && (
              <Button 
                size="lg" 
                variant="outline"
                onClick={() => navigate("/expert")}
              >
                <Users className="w-5 h-5 ml-2" />
                لوحة الخبراء
              </Button>
            )}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container py-16">
        <h3 className="text-3xl font-bold text-center mb-12">كيف يعمل النظام؟</h3>
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          <Card className="border-2 hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                <Camera className="w-6 h-6 text-green-700" />
              </div>
              <CardTitle>1. رفع الصور</CardTitle>
              <CardDescription>
                قم برفع صور واضحة للأضرار من زوايا مختلفة
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-2 hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                <Brain className="w-6 h-6 text-green-700" />
              </div>
              <CardTitle>2. التحليل الذكي</CardTitle>
              <CardDescription>
                يقوم الذكاء الاصطناعي بتحليل الصور وتحديد الأضرار بدقة
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-2 hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                <FileText className="w-6 h-6 text-green-600" />
              </div>
              <CardTitle>3. الفاتورة المفصلة</CardTitle>
              <CardDescription>
                احصل على فاتورة شاملة بكل الأضرار والتكاليف
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="container py-16">
        <div className="max-w-4xl mx-auto">
          <h3 className="text-3xl font-bold text-center mb-12">المميزات الرئيسية</h3>
          <div className="grid md:grid-cols-2 gap-6">
            {[
              "تحليل فوري للأضرار باستخدام الذكاء الاصطناعي",
              "تقديرات دقيقة مبنية على خبرة متخصصين محليين",
              "فواتير مفصلة تشمل تكلفة القطع والعمالة",
              "واجهة سهلة الاستخدام باللغة العربية",
              "حفظ التقييمات والرجوع إليها لاحقاً",
              "نظام تعلم مستمر يتحسن مع كل تقييم"
            ].map((benefit, index) => (
              <div key={index} className="flex items-start gap-3">
                <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-1" />
                <p className="text-lg">{benefit}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Expert Panel CTA */}
      {isAuthenticated && (user?.role === 'expert' || user?.role === 'admin') && (
        <section className="container py-16">
          <Card className="bg-gradient-to-r from-green-700 to-green-600 text-white border-0">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl mb-4">أنت خبير معتمد!</CardTitle>
              <CardDescription className="text-green-100 text-lg">
                ساهم في تحسين دقة النظام من خلال إضافة تقييماتك الخبيرة
              </CardDescription>
              <div className="pt-4">
                <Button 
                  size="lg" 
                  variant="secondary"
                  onClick={() => navigate("/expert")}
                >
                  <Users className="w-5 h-5 ml-2" />
                  الذهاب إلى لوحة الخبراء
                </Button>
              </div>
            </CardHeader>
          </Card>
        </section>
      )}

      {/* CTA Section */}
      <section className="container py-20">
        <Card className="bg-gradient-to-r from-green-700 to-green-600 text-white border-0">
          <CardContent className="py-12 text-center">
            <h3 className="text-3xl font-bold mb-4">جاهز للبدء؟</h3>
            <p className="text-xl text-green-100 mb-8 max-w-2xl mx-auto">
              احصل على تقدير دقيق لتكاليف إصلاح مركبتك في دقائق
            </p>
            <Button 
              size="lg" 
              variant="secondary"
              onClick={() => navigate("/predict")}
            >
              <Camera className="w-5 h-5 ml-2" />
              ابدأ التحليل الآن
              <ArrowRight className="w-5 h-5 mr-2" />
            </Button>
          </CardContent>
        </Card>
      </section>

      {/* Footer */}
      <footer className="border-t bg-white/80 backdrop-blur-sm py-8">
        <div className="container text-center text-gray-600">
          <p className="font-semibold mb-2">{APP_TITLE}</p>
          <p className="text-sm">مدعوم بالذكاء الاصطناعي وخبرة المتخصصين المحليين</p>
        </div>
      </footer>
    </div>
  );
}
