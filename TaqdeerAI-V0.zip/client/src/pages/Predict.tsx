import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { Upload, Loader2, X, FileImage } from "lucide-react";
import { useState, useRef } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";

interface UploadedImage {
  file: File;
  preview: string;
  url?: string;
}

export default function Predict() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <PredictContent />
    </div>
  );
}

function PredictContent() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [images, setImages] = useState<UploadedImage[]>([]);
  const [vehicleAge, setVehicleAge] = useState<number>();
  const [mileage, setMileage] = useState<number>();
  const [vehicleType, setVehicleType] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const analyzeDamage = trpc.predict.analyzeDamage.useMutation({
    onSuccess: (data) => {
      console.log('[Analysis Success]', data);
      setIsAnalyzing(false);
      toast.success("تم تحليل الأضرار بنجاح!");
      // Navigate to invoice page
      setTimeout(() => {
        navigate(`/invoice/${data.predictionId}`);
      }, 500);
    },
    onError: (error) => {
      console.error('[Analysis Error]', error);
      setIsAnalyzing(false);
      toast.error("فشل تحليل الأضرار: " + error.message);
    }
  });

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    
    files.forEach(file => {
      if (!file.type.startsWith('image/')) {
        toast.error(`${file.name} ليس ملف صورة`);
        return;
      }

      if (file.size > 10 * 1024 * 1024) { // 10MB limit
        toast.error(`${file.name} حجمه كبير جداً (الحد الأقصى 10MB)`);
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        setImages(prev => [...prev, {
          file,
          preview: e.target?.result as string,
        }]);
      };
      reader.readAsDataURL(file);
    });

    // Reset input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleAnalyze = async () => {
    if (images.length === 0) {
      toast.error("يجب رفع صورة واحدة على الأقل");
      return;
    }

    setIsAnalyzing(true);

    try {
      // Convert images to format needed for API
      const imageData = images.map(img => ({
        url: img.preview,
        mimeType: img.file.type,
      }));

      analyzeDamage.mutate({
        images: imageData,
        vehicleAge,
        mileage,
        vehicleType: vehicleType || undefined,
      });
    } catch (error) {
      toast.error("حدث خطأ أثناء التحليل");
      setIsAnalyzing(false);
    }
  };

  // Allow access without authentication

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 py-8">
      <div className="container max-w-4xl">
        <Card>
          <CardHeader>
            <CardTitle className="text-3xl">تحليل أضرار المركبة 🔍</CardTitle>
            <CardDescription>
              قم برفع صور الأضرار وسنقوم بتحليلها وتقديم تقدير مفصل للتكاليف
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Image Upload Section */}
            <div className="space-y-4">
              <Label>صور الأضرار</Label>
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-primary transition-colors"
              >
                <Upload className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                <p className="text-lg font-medium mb-2">انقر لرفع الصور</p>
                <p className="text-sm text-gray-500">أو اسحب الصور هنا</p>
                <p className="text-xs text-gray-400 mt-2">PNG, JPG, WEBP (حد أقصى 10MB لكل صورة)</p>
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                multiple
                onChange={handleFileSelect}
                className="hidden"
              />

              {/* Image Previews */}
              {images.length > 0 && (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {images.map((img, index) => (
                    <div key={index} className="relative group">
                      <img
                        src={img.preview}
                        alt={`Preview ${index + 1}`}
                        className="w-full h-40 object-cover rounded-lg"
                      />
                      <Button
                        type="button"
                        variant="destructive"
                        size="icon"
                        className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => removeImage(index)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                      <div className="absolute bottom-2 left-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                        {img.file.name}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Vehicle Information (Optional) */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">معلومات المركبة (اختياري)</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="vehicleAge">عمر المركبة (سنوات)</Label>
                  <Input
                    id="vehicleAge"
                    type="number"
                    value={vehicleAge || ""}
                    onChange={(e) => setVehicleAge(e.target.value ? Number(e.target.value) : undefined)}
                    placeholder="5"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="mileage">المسافة المقطوعة (كم)</Label>
                  <Input
                    id="mileage"
                    type="number"
                    value={mileage || ""}
                    onChange={(e) => setMileage(e.target.value ? Number(e.target.value) : undefined)}
                    placeholder="80000"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="vehicleType">نوع المركبة</Label>
                  <Select value={vehicleType} onValueChange={setVehicleType}>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر النوع" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sedan">سيدان</SelectItem>
                      <SelectItem value="suv">دفع رباعي</SelectItem>
                      <SelectItem value="truck">شاحنة</SelectItem>
                      <SelectItem value="coupe">كوبيه</SelectItem>
                      <SelectItem value="hatchback">هاتشباك</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Analyze Button */}
            <Button
              onClick={handleAnalyze}
              disabled={isAnalyzing || images.length === 0}
              className="w-full"
              size="lg"
            >
              {isAnalyzing ? (
                <>
                  <Loader2 className="w-5 h-5 ml-2 animate-spin" />
                  جاري التحليل... قد يستغرق هذا بضع ثوانٍ
                </>
              ) : (
                <>
                  <FileImage className="w-5 h-5 ml-2" />
                  تحليل الأضرار وإنشاء الفاتورة
                </>
              )}
            </Button>

            {/* Info Box */}
            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="pt-6">
                <h4 className="font-semibold mb-2">💡 نصائح للحصول على أفضل النتائج:</h4>
                <ul className="text-sm space-y-1 text-gray-700">
                  <li>• التقط صوراً واضحة للأضرار من زوايا مختلفة</li>
                  <li>• تأكد من الإضاءة الجيدة</li>
                  <li>• قم بتصوير كل ضرر بشكل منفصل</li>
                  <li>• يمكنك رفع حتى 10 صور</li>
                </ul>
              </CardContent>
            </Card>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
