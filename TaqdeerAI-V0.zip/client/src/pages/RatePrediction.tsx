import { useState } from "react";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Loader2, Star, ArrowLeft, CheckCircle2 } from "lucide-react";
import { useRoute, useLocation } from "wouter";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

export default function RatePrediction() {
  const [, params] = useRoute("/rate/:id");
  const [, setLocation] = useLocation();
  const predictionId = params?.id ? parseInt(params.id) : 0;

  const [accuracyRating, setAccuracyRating] = useState(0);
  const [hoveredStar, setHoveredStar] = useState(0);
  const [actualTotalCost, setActualTotalCost] = useState("");
  const [timeToRepair, setTimeToRepair] = useState("");
  const [comments, setComments] = useState("");
  const [wouldRecommend, setWouldRecommend] = useState<boolean | undefined>(undefined);
  const [submitted, setSubmitted] = useState(false);

  const { data, isLoading } = trpc.predict.getPredictionDetails.useQuery(
    { predictionId },
    { enabled: predictionId > 0 }
  );

  const existingRating = trpc.rating.getRatingByPrediction.useQuery(
    { predictionId },
    { enabled: predictionId > 0 }
  );

  const rateMutation = trpc.rating.ratePrediction.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      toast.success("تم إرسال التقييم بنجاح!");
    },
    onError: (error) => {
      toast.error("فشل إرسال التقييم: " + error.message);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (accuracyRating === 0) {
      toast.error("يرجى تحديد تقييم الدقة");
      return;
    }

    rateMutation.mutate({
      predictionId,
      accuracyRating,
      actualTotalCost: actualTotalCost ? parseFloat(actualTotalCost) : undefined,
      timeToRepair: timeToRepair ? parseInt(timeToRepair) : undefined,
      comments: comments || undefined,
      wouldRecommend,
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-green-600" />
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle className="text-red-600">خطأ</CardTitle>
              <CardDescription>لم يتم العثور على التنبؤ</CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={() => setLocation("/history")} variant="outline">
                <ArrowLeft className="ml-2 h-4 w-4" />
                العودة إلى السجل
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (submitted || existingRating.data) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center p-4">
          <Card className="w-full max-w-2xl">
            <CardHeader className="text-center">
              <div className="mx-auto mb-4 w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                <CheckCircle2 className="w-10 h-10 text-green-600" />
              </div>
              <CardTitle className="text-2xl">شكراً لتقييمك!</CardTitle>
              <CardDescription className="text-lg">
                تقييمك يساعدنا في تحسين دقة النظام
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {existingRating.data && existingRating.data.accuracyRating && (
                <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold">تقييم الدقة:</span>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`w-5 h-5 ${
                            star <= (existingRating.data?.accuracyRating || 0)
                              ? "fill-yellow-400 text-yellow-400"
                              : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                  {existingRating.data.actualTotalCost && (
                    <p>
                      <span className="font-semibold">التكلفة الفعلية:</span>{" "}
                      {existingRating.data.actualTotalCost.toFixed(2)} ر.س
                    </p>
                  )}
                  {existingRating.data.comments && (
                    <p>
                      <span className="font-semibold">التعليقات:</span>{" "}
                      {existingRating.data.comments}
                    </p>
                  )}
                </div>
              )}
              <div className="flex gap-4">
                <Button onClick={() => setLocation("/history")} variant="outline" className="flex-1">
                  <ArrowLeft className="ml-2 h-4 w-4" />
                  العودة إلى السجل
                </Button>
                <Button onClick={() => setLocation("/")} className="flex-1">
                  الصفحة الرئيسية
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex-1 container py-8">
        <div className="max-w-3xl mx-auto">
          <Button
            onClick={() => setLocation("/history")}
            variant="ghost"
            className="mb-6"
          >
            <ArrowLeft className="ml-2 h-4 w-4" />
            العودة
          </Button>

          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">تقييم دقة التنبؤ</CardTitle>
              <CardDescription>
                ساعدنا في تحسين النظام من خلال تقييم دقة التنبؤ بعد الإصلاح الفعلي
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Prediction Summary */}
                <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                  <h3 className="font-semibold text-lg mb-3">ملخص التنبؤ</h3>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">التكلفة المتوقعة:</span>
                      <p className="font-semibold">{data.prediction.predictedTotalCost.toFixed(2)} ر.س</p>
                    </div>
                    <div>
                      <span className="text-gray-600">تكلفة العمالة:</span>
                      <p className="font-semibold">{data.prediction.predictedLaborCost.toFixed(2)} ر.س</p>
                    </div>
                    <div>
                      <span className="text-gray-600">نوع المركبة:</span>
                      <p className="font-semibold">{data.prediction.vehicleType || "غير محدد"}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">نوع الحادث:</span>
                      <p className="font-semibold">{data.prediction.accidentType || "غير محدد"}</p>
                    </div>
                  </div>
                </div>

                {/* Accuracy Rating */}
                <div className="space-y-2">
                  <Label className="text-base font-semibold">
                    تقييم دقة التنبؤ <span className="text-red-500">*</span>
                  </Label>
                  <p className="text-sm text-gray-600">
                    ما مدى دقة التنبؤ مقارنة بالتكلفة الفعلية؟
                  </p>
                  <div className="flex gap-2 py-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setAccuracyRating(star)}
                        onMouseEnter={() => setHoveredStar(star)}
                        onMouseLeave={() => setHoveredStar(0)}
                        className="transition-transform hover:scale-110"
                      >
                        <Star
                          className={`w-10 h-10 ${
                            star <= (hoveredStar || accuracyRating)
                              ? "fill-yellow-400 text-yellow-400"
                              : "text-gray-300"
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>غير دقيق</span>
                    <span>دقيق جداً</span>
                  </div>
                </div>

                {/* Actual Cost */}
                <div className="space-y-2">
                  <Label htmlFor="actualCost" className="text-base font-semibold">
                    التكلفة الفعلية للإصلاح (ر.س)
                  </Label>
                  <Input
                    id="actualCost"
                    type="number"
                    step="0.01"
                    value={actualTotalCost}
                    onChange={(e) => setActualTotalCost(e.target.value)}
                    placeholder="أدخل التكلفة الفعلية"
                  />
                  <p className="text-sm text-gray-600">
                    التكلفة المتوقعة كانت: {data.prediction.predictedTotalCost.toFixed(2)} ر.س
                  </p>
                </div>

                {/* Time to Repair */}
                <div className="space-y-2">
                  <Label htmlFor="timeToRepair" className="text-base font-semibold">
                    مدة الإصلاح (بالأيام)
                  </Label>
                  <Input
                    id="timeToRepair"
                    type="number"
                    value={timeToRepair}
                    onChange={(e) => setTimeToRepair(e.target.value)}
                    placeholder="كم يوماً استغرق الإصلاح؟"
                  />
                </div>

                {/* Would Recommend */}
                <div className="space-y-2">
                  <Label className="text-base font-semibold">
                    هل توصي باستخدام هذا النظام؟
                  </Label>
                  <RadioGroup
                    value={wouldRecommend === undefined ? "" : wouldRecommend.toString()}
                    onValueChange={(value) => setWouldRecommend(value === "true")}
                  >
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <RadioGroupItem value="true" id="recommend-yes" />
                      <Label htmlFor="recommend-yes" className="cursor-pointer">نعم، أوصي به</Label>
                    </div>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <RadioGroupItem value="false" id="recommend-no" />
                      <Label htmlFor="recommend-no" className="cursor-pointer">لا، لا أوصي به</Label>
                    </div>
                  </RadioGroup>
                </div>

                {/* Comments */}
                <div className="space-y-2">
                  <Label htmlFor="comments" className="text-base font-semibold">
                    ملاحظات إضافية
                  </Label>
                  <Textarea
                    id="comments"
                    value={comments}
                    onChange={(e) => setComments(e.target.value)}
                    placeholder="شاركنا ملاحظاتك حول دقة التنبؤ..."
                    rows={4}
                  />
                </div>

                {/* Submit Button */}
                <div className="flex gap-4 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setLocation("/history")}
                    className="flex-1"
                  >
                    إلغاء
                  </Button>
                  <Button
                    type="submit"
                    disabled={rateMutation.isPending || accuracyRating === 0}
                    className="flex-1"
                  >
                    {rateMutation.isPending ? (
                      <>
                        <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                        جاري الإرسال...
                      </>
                    ) : (
                      "إرسال التقييم"
                    )}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
