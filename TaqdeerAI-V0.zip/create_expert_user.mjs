import { drizzle } from "drizzle-orm/mysql2";
import { users } from "./drizzle/schema.ts";

const db = drizzle(process.env.DATABASE_URL);

async function createExpertUser() {
  try {
    await db.insert(users).values({
      openId: "expert-demo-12345",
      name: "خبير تجريبي",
      email: "expert@demo.sa",
      loginMethod: "demo",
      role: "expert",
      lastSignedIn: new Date(),
    });
    
    console.log("✅ تم إنشاء حساب الخبير التجريبي بنجاح!");
    console.log("📧 البريد: expert@demo.sa");
    console.log("🔑 OpenID: expert-demo-12345");
    console.log("👤 الدور: expert");
  } catch (error) {
    console.error("❌ خطأ:", error.message);
  }
  process.exit(0);
}

createExpertUser();
