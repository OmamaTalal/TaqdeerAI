CREATE TABLE `damage_images` (
	`id` int AUTO_INCREMENT NOT NULL,
	`assessmentId` int,
	`assessmentType` enum('expert','prediction') NOT NULL,
	`imageUrl` text NOT NULL,
	`imageKey` text NOT NULL,
	`mimeType` varchar(100),
	`fileSize` int,
	`uploadedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `damage_images_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `damage_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`assessmentId` int NOT NULL,
	`damageType` varchar(100) NOT NULL,
	`description` text,
	`partCost` int NOT NULL,
	`laborCost` int NOT NULL,
	`quantity` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `damage_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `expert_assessments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`expertId` int NOT NULL,
	`vehicleAge` int,
	`mileage` int,
	`vehicleType` varchar(50),
	`accidentType` varchar(50),
	`damageSeverity` varchar(50),
	`notes` text,
	`totalCost` int NOT NULL,
	`laborCost` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `expert_assessments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `predicted_damage_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`predictionId` int NOT NULL,
	`damageType` varchar(100) NOT NULL,
	`description` text,
	`partCost` int NOT NULL,
	`laborCost` int NOT NULL,
	`quantity` int NOT NULL DEFAULT 1,
	`confidence` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `predicted_damage_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `predictions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`vehicleAge` int,
	`mileage` int,
	`vehicleType` varchar(50),
	`accidentType` varchar(50),
	`damageSeverity` varchar(50),
	`predictedTotalCost` int NOT NULL,
	`predictedLaborCost` int NOT NULL,
	`status` enum('pending','completed','failed') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `predictions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','admin','expert') NOT NULL DEFAULT 'user';