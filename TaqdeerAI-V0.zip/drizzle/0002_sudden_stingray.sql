CREATE TABLE `item_ratings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ratingId` int NOT NULL,
	`predictedItemId` int NOT NULL,
	`wasAccurate` boolean NOT NULL,
	`actualCost` int,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `item_ratings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `prediction_ratings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`predictionId` int NOT NULL,
	`userId` int NOT NULL,
	`accuracyRating` int NOT NULL,
	`actualTotalCost` int,
	`costDifference` int,
	`timeToRepair` int,
	`comments` text,
	`wouldRecommend` boolean,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `prediction_ratings_id` PRIMARY KEY(`id`)
);
