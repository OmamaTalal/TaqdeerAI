import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, decimal } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin", "expert"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Damage assessments created by experts for training the model
 */
export const expertAssessments = mysqlTable("expert_assessments", {
  id: int("id").autoincrement().primaryKey(),
  expertId: int("expertId").notNull(), // references users.id
  vehicleAge: int("vehicleAge"),
  mileage: int("mileage"),
  vehicleType: varchar("vehicleType", { length: 50 }),
  accidentType: varchar("accidentType", { length: 50 }),
  damageSeverity: varchar("damageSeverity", { length: 50 }),
  notes: text("notes"),
  totalCost: int("totalCost").notNull(), // in cents to avoid decimal issues
  laborCost: int("laborCost").notNull(), // in cents
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ExpertAssessment = typeof expertAssessments.$inferSelect;
export type InsertExpertAssessment = typeof expertAssessments.$inferInsert;

/**
 * Images uploaded for damage assessment
 */
export const damageImages = mysqlTable("damage_images", {
  id: int("id").autoincrement().primaryKey(),
  assessmentId: int("assessmentId"), // references expertAssessments.id or predictions.id
  assessmentType: mysqlEnum("assessmentType", ["expert", "prediction"]).notNull(),
  imageUrl: text("imageUrl").notNull(),
  imageKey: text("imageKey").notNull(), // S3 key for deletion
  mimeType: varchar("mimeType", { length: 100 }),
  fileSize: int("fileSize"), // in bytes
  uploadedAt: timestamp("uploadedAt").defaultNow().notNull(),
});

export type DamageImage = typeof damageImages.$inferSelect;
export type InsertDamageImage = typeof damageImages.$inferInsert;

/**
 * Detailed damage items within an assessment
 */
export const damageItems = mysqlTable("damage_items", {
  id: int("id").autoincrement().primaryKey(),
  assessmentId: int("assessmentId").notNull(), // references expertAssessments.id
  damageType: varchar("damageType", { length: 100 }).notNull(), // e.g., "Front bumper scratch"
  description: text("description"),
  partCost: int("partCost").notNull(), // in cents
  laborCost: int("laborCost").notNull(), // in cents
  quantity: int("quantity").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type DamageItem = typeof damageItems.$inferSelect;
export type InsertDamageItem = typeof damageItems.$inferInsert;

/**
 * User predictions/assessments
 */
export const predictions = mysqlTable("predictions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"), // references users.id, nullable for guest users
  vehicleAge: int("vehicleAge"),
  mileage: int("mileage"),
  vehicleType: varchar("vehicleType", { length: 50 }),
  accidentType: varchar("accidentType", { length: 50 }),
  damageSeverity: varchar("damageSeverity", { length: 50 }),
  predictedTotalCost: int("predictedTotalCost").notNull(), // in cents
  predictedLaborCost: int("predictedLaborCost").notNull(), // in cents
  status: mysqlEnum("status", ["pending", "completed", "failed"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Prediction = typeof predictions.$inferSelect;
export type InsertPrediction = typeof predictions.$inferInsert;

/**
 * Predicted damage items for user predictions
 */
export const predictedDamageItems = mysqlTable("predicted_damage_items", {
  id: int("id").autoincrement().primaryKey(),
  predictionId: int("predictionId").notNull(), // references predictions.id
  damageType: varchar("damageType", { length: 100 }).notNull(),
  description: text("description"),
  partCost: int("partCost").notNull(), // in cents
  laborCost: int("laborCost").notNull(), // in cents
  quantity: int("quantity").default(1).notNull(),
  confidence: int("confidence"), // 0-100
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PredictedDamageItem = typeof predictedDamageItems.$inferSelect;
export type InsertPredictedDamageItem = typeof predictedDamageItems.$inferInsert;

/**
 * User ratings for prediction accuracy after actual repair
 */
export const predictionRatings = mysqlTable("prediction_ratings", {
  id: int("id").autoincrement().primaryKey(),
  predictionId: int("predictionId").notNull(), // references predictions.id
  userId: int("userId").notNull(), // references users.id
  accuracyRating: int("accuracyRating").notNull(), // 1-5 stars
  actualTotalCost: int("actualTotalCost"), // in cents, actual cost after repair
  costDifference: int("costDifference"), // difference between predicted and actual
  timeToRepair: int("timeToRepair"), // in days
  comments: text("comments"),
  wouldRecommend: boolean("wouldRecommend"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PredictionRating = typeof predictionRatings.$inferSelect;
export type InsertPredictionRating = typeof predictionRatings.$inferInsert;

/**
 * Detailed item-level ratings for each predicted damage item
 */
export const itemRatings = mysqlTable("item_ratings", {
  id: int("id").autoincrement().primaryKey(),
  ratingId: int("ratingId").notNull(), // references predictionRatings.id
  predictedItemId: int("predictedItemId").notNull(), // references predictedDamageItems.id
  wasAccurate: boolean("wasAccurate").notNull(), // was this item correctly identified?
  actualCost: int("actualCost"), // in cents, actual cost for this specific item
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ItemRating = typeof itemRatings.$inferSelect;
export type InsertItemRating = typeof itemRatings.$inferInsert;
