import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, 
  users,
  expertAssessments,
  InsertExpertAssessment,
  damageImages,
  InsertDamageImage,
  damageItems,
  InsertDamageItem,
  predictions,
  InsertPrediction,
  predictedDamageItems,
  InsertPredictedDamageItem,
  predictionRatings,
  InsertPredictionRating,
  itemRatings,
  InsertItemRating
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Expert Assessment Functions
export async function createExpertAssessment(assessment: InsertExpertAssessment) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.insert(expertAssessments).values(assessment);
  return 0;
}

export async function getExpertAssessments(expertId?: number) {
  const db = await getDb();
  if (!db) return [];

  if (expertId) {
    return await db.select().from(expertAssessments)
      .where(eq(expertAssessments.expertId, expertId))
      .orderBy(desc(expertAssessments.createdAt));
  }

  return await db.select().from(expertAssessments)
    .orderBy(desc(expertAssessments.createdAt));
}

export async function getExpertAssessmentById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(expertAssessments)
    .where(eq(expertAssessments.id, id))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Damage Image Functions
export async function createDamageImage(image: InsertDamageImage) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.insert(damageImages).values(image);
  return 0;
}

export async function getDamageImagesByAssessment(assessmentId: number, assessmentType: "expert" | "prediction") {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(damageImages)
    .where(eq(damageImages.assessmentId, assessmentId));
}

// Damage Item Functions
export async function createDamageItem(item: InsertDamageItem) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.insert(damageItems).values(item);
  return 0;
}

export async function getDamageItemsByAssessment(assessmentId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(damageItems)
    .where(eq(damageItems.assessmentId, assessmentId));
}

// Prediction Functions
export async function createPrediction(prediction: InsertPrediction) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(predictions).values(prediction);
  // Return the auto-incremented ID
  return Number(result[0].insertId);
}

export async function getPredictionById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(predictions)
    .where(eq(predictions.id, id))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserPredictions(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(predictions)
    .where(eq(predictions.userId, userId))
    .orderBy(desc(predictions.createdAt));
}

// Predicted Damage Item Functions
export async function createPredictedDamageItem(item: InsertPredictedDamageItem) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.insert(predictedDamageItems).values(item);
  return 0;
}

export async function getPredictedDamageItemsByPrediction(predictionId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(predictedDamageItems)
    .where(eq(predictedDamageItems.predictionId, predictionId));
}

// Rating Functions
export async function createPredictionRating(rating: InsertPredictionRating) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.insert(predictionRatings).values(rating);
  
  // Get the last inserted rating
  const result = await db.select().from(predictionRatings)
    .where(eq(predictionRatings.predictionId, rating.predictionId))
    .orderBy(desc(predictionRatings.createdAt))
    .limit(1);
  
  return result[0];
}

export async function getRatingByPrediction(predictionId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(predictionRatings)
    .where(eq(predictionRatings.predictionId, predictionId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function createItemRating(itemRating: InsertItemRating) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.insert(itemRatings).values(itemRating);
  return { id: 0, ...itemRating };
}

export async function getItemRatingsByRating(ratingId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(itemRatings)
    .where(eq(itemRatings.ratingId, ratingId));
}

export async function getRatingStatistics() {
  const db = await getDb();
  if (!db) return {
    totalRatings: 0,
    averageAccuracy: 0,
    averageCostDifference: 0,
    recommendationRate: 0,
  };

  const ratings = await db.select().from(predictionRatings);
  
  if (ratings.length === 0) {
    return {
      totalRatings: 0,
      averageAccuracy: 0,
      averageCostDifference: 0,
      recommendationRate: 0,
    };
  }

  const totalRatings = ratings.length;
  const averageAccuracy = ratings.reduce((sum, r) => sum + r.accuracyRating, 0) / totalRatings;
  
  const ratingsWithCost = ratings.filter(r => r.costDifference !== null);
  const averageCostDifference = ratingsWithCost.length > 0
    ? ratingsWithCost.reduce((sum, r) => sum + (r.costDifference || 0), 0) / ratingsWithCost.length
    : 0;

  const ratingsWithRecommendation = ratings.filter(r => r.wouldRecommend !== null);
  const recommendationRate = ratingsWithRecommendation.length > 0
    ? (ratingsWithRecommendation.filter(r => r.wouldRecommend === true).length / ratingsWithRecommendation.length) * 100
    : 0;

  return {
    totalRatings,
    averageAccuracy,
    averageCostDifference,
    recommendationRate,
  };
}
