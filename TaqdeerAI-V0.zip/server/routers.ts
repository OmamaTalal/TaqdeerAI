import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { storagePut } from "./storage";
import { invokeLLM } from "./_core/llm";
import { TRPCError } from "@trpc/server";

// Helper to convert cents to SAR (Saudi Riyal)
// 1 USD = 3.75 SAR, so we multiply by 3.75
function centsToSAR(cents: number): number {
  return (cents / 100) * 3.75;
}

// Helper to convert SAR to cents
// Divide by 3.75 to get USD equivalent, then convert to cents
function sarToCents(sar: number): number {
  return Math.round((sar / 3.75) * 100);
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Expert Assessment Router
  expert: router({
    // Create new expert assessment
    createAssessment: protectedProcedure
      .input(z.object({
        vehicleAge: z.number().optional(),
        mileage: z.number().optional(),
        vehicleType: z.string().optional(),
        accidentType: z.string().optional(),
        damageSeverity: z.string().optional(),
        notes: z.string().optional(),
        totalCost: z.number(), // in dollars
        laborCost: z.number(), // in dollars
        damageItems: z.array(z.object({
          damageType: z.string(),
          description: z.string().optional(),
          partCost: z.number(), // in dollars
          laborCost: z.number(), // in dollars
          quantity: z.number().default(1),
        })),
      }))
      .mutation(async ({ ctx, input }) => {
        // Check if user is expert or admin
        if (ctx.user.role !== 'expert' && ctx.user.role !== 'admin') {
          throw new TRPCError({ 
            code: 'FORBIDDEN',
            message: 'Only experts can create assessments'
          });
        }

        // Create assessment
        const assessmentId = await db.createExpertAssessment({
          expertId: ctx.user.id,
          vehicleAge: input.vehicleAge,
          mileage: input.mileage,
          vehicleType: input.vehicleType,
          accidentType: input.accidentType,
          damageSeverity: input.damageSeverity,
          notes: input.notes,
          totalCost: sarToCents(input.totalCost),
          laborCost: sarToCents(input.laborCost),
        });

        // Create damage items
        for (const item of input.damageItems) {
          await db.createDamageItem({
            assessmentId,
            damageType: item.damageType,
            description: item.description,
            partCost: sarToCents(item.partCost),
            laborCost: sarToCents(item.laborCost),
            quantity: item.quantity,
          });
        }

        return { success: true, assessmentId };
      }),

    // Get expert assessments
    getAssessments: protectedProcedure
      .query(async ({ ctx }) => {
        const assessments = await db.getExpertAssessments(ctx.user.id);
        return assessments.map(a => ({
          ...a,
          totalCost: centsToSAR(a.totalCost),
          laborCost: centsToSAR(a.laborCost),
        }));
      }),

    // Get assessment details with items
    getAssessmentDetails: protectedProcedure
      .input(z.object({ assessmentId: z.number() }))
      .query(async ({ input }) => {
        const assessment = await db.getExpertAssessmentById(input.assessmentId);
        if (!assessment) {
          throw new TRPCError({ code: 'NOT_FOUND' });
        }

        const items = await db.getDamageItemsByAssessment(input.assessmentId);
        const images = await db.getDamageImagesByAssessment(input.assessmentId, 'expert');

        return {
          assessment: {
            ...assessment,
            totalCost: centsToSAR(assessment.totalCost),
            laborCost: centsToSAR(assessment.laborCost),
          },
          items: items.map(item => ({
            ...item,
            partCost: centsToSAR(item.partCost),
            laborCost: centsToSAR(item.laborCost),
          })),
          images,
        };
      }),
  }),

  // Image Upload Router
  upload: router({
    // Upload image and save to S3
    uploadImage: protectedProcedure
      .input(z.object({
        imageData: z.string(), // base64 encoded image
        assessmentId: z.number(),
        assessmentType: z.enum(['expert', 'prediction']),
        mimeType: z.string(),
      }))
      .mutation(async ({ input }) => {
        // Decode base64 image
        const buffer = Buffer.from(input.imageData, 'base64');
        
        // Generate unique key
        const timestamp = Date.now();
        const random = Math.random().toString(36).substring(7);
        const fileKey = `damage-images/${input.assessmentType}/${input.assessmentId}/${timestamp}-${random}`;
        
        // Upload to S3
        const { url } = await storagePut(fileKey, buffer, input.mimeType);
        
        // Save to database
        await db.createDamageImage({
          assessmentId: input.assessmentId,
          assessmentType: input.assessmentType,
          imageUrl: url,
          imageKey: fileKey,
          mimeType: input.mimeType,
          fileSize: buffer.length,
        });

        return { success: true, url };
      }),
  }),

  // Prediction Router
  predict: router({
    // Analyze images and create prediction
    analyzeDamage: publicProcedure
      .input(z.object({
        images: z.array(z.object({
          url: z.string(),
          mimeType: z.string(),
        })),
        vehicleAge: z.number().optional(),
        mileage: z.number().optional(),
        vehicleType: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        // Get user ID if authenticated, otherwise use null
        const userId = ctx.user?.id || null;
        // Use LLM to analyze damage from images
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: "You are a vehicle damage assessment expert. Analyze the provided images and identify all damages, their severity, and estimated repair costs."
            },
            {
              role: "user",
              content: [
                {
                  type: "text",
                  text: `Analyze these vehicle damage images and provide detailed assessment. Vehicle info: Age: ${input.vehicleAge || 'unknown'}, Mileage: ${input.mileage || 'unknown'}, Type: ${input.vehicleType || 'unknown'}`
                },
                ...input.images.map(img => ({
                  type: "image_url" as const,
                  image_url: {
                    url: img.url,
                    detail: "high" as const
                  }
                }))
              ]
            }
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "damage_assessment",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  accidentType: { type: "string", description: "Type of accident (collision, scratch, dent, etc.)" },
                  damageSeverity: { type: "string", description: "Overall severity (minor, moderate, severe)" },
                  damageItems: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        damageType: { type: "string", description: "Specific damage type (e.g., 'Front bumper scratch')" },
                        description: { type: "string", description: "Detailed description" },
                        partCost: { type: "number", description: "Estimated part cost in dollars" },
                        laborCost: { type: "number", description: "Estimated labor cost in dollars" },
                        quantity: { type: "integer", description: "Quantity of items" },
                        confidence: { type: "integer", description: "Confidence level 0-100" }
                      },
                      required: ["damageType", "description", "partCost", "laborCost", "quantity", "confidence"],
                      additionalProperties: false
                    }
                  }
                },
                required: ["accidentType", "damageSeverity", "damageItems"],
                additionalProperties: false
              }
            }
          }
        });

        const content = response.choices[0]?.message?.content;
        console.log('[LLM Response]', content);
        
        let analysis;
        try {
          analysis = JSON.parse(typeof content === 'string' ? content : '{}');
        } catch (error) {
          console.error('[JSON Parse Error]', error);
          throw new TRPCError({ 
            code: 'INTERNAL_SERVER_ERROR', 
            message: 'Failed to parse LLM response' 
          });
        }
        
        // Validate analysis structure
        if (!analysis.damageItems || !Array.isArray(analysis.damageItems) || analysis.damageItems.length === 0) {
          console.error('[Invalid Analysis]', analysis);
          throw new TRPCError({ 
            code: 'INTERNAL_SERVER_ERROR', 
            message: 'LLM did not return valid damage items' 
          });
        }
        
        // Calculate total costs
        let totalPartCost = 0;
        let totalLaborCost = 0;
        for (const item of analysis.damageItems || []) {
          totalPartCost += item.partCost * item.quantity;
          totalLaborCost += item.laborCost * item.quantity;
        }

        // Create prediction
        const predictionId = await db.createPrediction({
          userId: userId,
          vehicleAge: input.vehicleAge,
          mileage: input.mileage,
          vehicleType: input.vehicleType,
          accidentType: analysis.accidentType,
          damageSeverity: analysis.damageSeverity,
          predictedTotalCost: sarToCents(totalPartCost + totalLaborCost),
          predictedLaborCost: sarToCents(totalLaborCost),
          status: 'completed',
        });

        // Save damage items
        for (const item of analysis.damageItems || []) {
          await db.createPredictedDamageItem({
            predictionId,
            damageType: item.damageType,
            description: item.description,
            partCost: sarToCents(item.partCost),
            laborCost: sarToCents(item.laborCost),
            quantity: item.quantity,
            confidence: item.confidence,
          });
        }

        // Upload and save images to S3
        for (let i = 0; i < input.images.length; i++) {
          const img = input.images[i];
          
          // Check if it's a base64 data URL
          if (img.url.startsWith('data:')) {
            // Extract base64 data
            const base64Data = img.url.split(',')[1];
            const buffer = Buffer.from(base64Data, 'base64');
            
            // Generate unique key
            const timestamp = Date.now();
            const random = Math.random().toString(36).substring(7);
            const fileKey = `damage-images/prediction/${predictionId}/${timestamp}-${i}-${random}`;
            
            // Upload to S3
            const { url } = await storagePut(fileKey, buffer, img.mimeType);
            
            // Save to database with S3 URL
            await db.createDamageImage({
              assessmentId: predictionId,
              assessmentType: 'prediction',
              imageUrl: url,
              imageKey: fileKey,
              mimeType: img.mimeType,
              fileSize: buffer.length,
            });
          } else {
            // Already an S3 URL
            const timestamp = Date.now();
            await db.createDamageImage({
              assessmentId: predictionId,
              assessmentType: 'prediction',
              imageUrl: img.url,
              imageKey: `prediction-${predictionId}-${timestamp}-${i}`,
              mimeType: img.mimeType,
            });
          }
        }

        return {
          success: true,
          predictionId,
          analysis: {
            ...analysis,
            totalCost: totalPartCost + totalLaborCost,
            laborCost: totalLaborCost,
          }
        };
      }),

    // Get prediction details
    getPredictionDetails: publicProcedure
      .input(z.object({ predictionId: z.number() }))
      .query(async ({ input }) => {
        const prediction = await db.getPredictionById(input.predictionId);
        if (!prediction) {
          throw new TRPCError({ code: 'NOT_FOUND' });
        }

        const items = await db.getPredictedDamageItemsByPrediction(input.predictionId);
        const images = await db.getDamageImagesByAssessment(input.predictionId, 'prediction');

        return {
          prediction: {
            ...prediction,
            predictedTotalCost: centsToSAR(prediction.predictedTotalCost),
            predictedLaborCost: centsToSAR(prediction.predictedLaborCost),
          },
          items: items.map(item => ({
            ...item,
            partCost: centsToSAR(item.partCost),
            laborCost: centsToSAR(item.laborCost),
          })),
          images,
        };
      }),

    // Get user predictions
    getMyPredictions: protectedProcedure
      .query(async ({ ctx }) => {
        const predictions = await db.getUserPredictions(ctx.user.id);
        return predictions.map(p => ({
          ...p,
          predictedTotalCost: centsToSAR(p.predictedTotalCost),
          predictedLaborCost: centsToSAR(p.predictedLaborCost),
        }));
      }),
  }),

  // Rating Router
  rating: router({
    // Create or update rating for a prediction
    ratePrediction: protectedProcedure
      .input(z.object({
        predictionId: z.number(),
        accuracyRating: z.number().min(1).max(5),
        actualTotalCost: z.number().optional(), // in SAR
        timeToRepair: z.number().optional(), // in days
        comments: z.string().optional(),
        wouldRecommend: z.boolean().optional(),
        itemRatings: z.array(z.object({
          predictedItemId: z.number(),
          wasAccurate: z.boolean(),
          actualCost: z.number().optional(), // in SAR
          notes: z.string().optional(),
        })).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const { predictionId, actualTotalCost, itemRatings, ...ratingData } = input;

        // Check if prediction exists
        const prediction = await db.getPredictionById(predictionId);
        if (!prediction) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Prediction not found' });
        }

        // Calculate cost difference if actual cost provided
        let costDifference = null;
        if (actualTotalCost) {
          const actualCostCents = sarToCents(actualTotalCost);
          costDifference = actualCostCents - prediction.predictedTotalCost;
        }

        // Create or update rating
        const rating = await db.createPredictionRating({
          predictionId,
          userId: ctx.user.id,
          actualTotalCost: actualTotalCost ? sarToCents(actualTotalCost) : null,
          costDifference,
          ...ratingData,
        });

        // Create item ratings if provided
        if (itemRatings && itemRatings.length > 0) {
          for (const itemRating of itemRatings) {
            await db.createItemRating({
              ratingId: rating.id,
              predictedItemId: itemRating.predictedItemId,
              wasAccurate: itemRating.wasAccurate,
              actualCost: itemRating.actualCost ? sarToCents(itemRating.actualCost) : null,
              notes: itemRating.notes,
            });
          }
        }

        return { success: true, ratingId: rating.id };
      }),

    // Get rating for a specific prediction
    getRatingByPrediction: publicProcedure
      .input(z.object({ predictionId: z.number() }))
      .query(async ({ input }) => {
        const rating = await db.getRatingByPrediction(input.predictionId);
        if (!rating) return null;

        const itemRatings = await db.getItemRatingsByRating(rating.id);

        return {
          ...rating,
          actualTotalCost: rating.actualTotalCost ? centsToSAR(rating.actualTotalCost) : null,
          costDifference: rating.costDifference ? centsToSAR(rating.costDifference) : null,
          itemRatings: itemRatings.map(ir => ({
            ...ir,
            actualCost: ir.actualCost ? centsToSAR(ir.actualCost) : null,
          })),
        };
      }),

    // Get statistics for all ratings (for experts/admin)
    getRatingStatistics: protectedProcedure
      .query(async () => {
        const stats = await db.getRatingStatistics();
        return stats;
      }),
  }),
});

export type AppRouter = typeof appRouter;
